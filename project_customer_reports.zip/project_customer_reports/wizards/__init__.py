# -*- coding: utf-8 -*-
from . import send_report_wizard
